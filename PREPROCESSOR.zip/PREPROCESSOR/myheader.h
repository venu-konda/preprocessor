#include<string.h>
#include<stdio.h>
#include<stdlib.h>
void *readFromFile(char *filename);
void *removeComments(char *p);
void *macroReplacement(char *p);
void *fileInclusion(char *p);
void writeToFile(char *p,char *filename);


