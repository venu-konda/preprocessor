#include "11.h"
#include<stdio.h> 
int main()
{
	printf(
			"QWDKJBJKWQ");
}
