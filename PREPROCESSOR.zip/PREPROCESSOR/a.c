#include<stdio.h>
int x;
int main()
{
	char a='A'; 
	printf("%c",a);
	printf("\n%d",a);
}
