#define max 10
int main()
{
	int i=max;
	printf("QWDKJBJKWQ");
}
