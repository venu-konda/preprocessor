#define max 10
int main()
{
	int a=max;
	int a1=max;
	int a2=max;
	int a22=max;
	int a3=max;
	printf("QWDKJBJKWQ");
}
